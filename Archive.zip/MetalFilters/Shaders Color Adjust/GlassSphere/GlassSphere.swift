//
//  GlassSphere.swift
//  MetalFilters
//
//  Created by HKBeast on 30/03/23.
//

import Foundation

class GlassSphere:ColorAdjustProtocol{
    var kernalName: String = "glassSphere"
    
    var value: Float = 0.01
    
    var min: CGFloat = 0.0
    
    var max: CGFloat = 1.0
    
    
}

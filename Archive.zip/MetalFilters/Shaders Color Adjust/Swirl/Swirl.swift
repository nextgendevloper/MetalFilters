//
//  Swirl.swift
//  MetalFilters
//
//  Created by HKBeast on 30/03/23.
//

import Foundation

class Swirl:ColorAdjustProtocol{
    var kernalName: String = "swirl"
    
    var value: Float = 0.0
    
    var min: CGFloat = 0.0
    
    var max: CGFloat = 1.0
    
    
}

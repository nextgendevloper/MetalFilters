//
//  PolkaDot.swift
//  MetalFilters
//
//  Created by HKBeast on 30/03/23.
//

import Foundation

class PolkaDot:ColorAdjustProtocol{
    var kernalName: String = "polkaDot"
    
    var value: Float = 1.0
    
    var min: CGFloat = 0.0
    
    var max: CGFloat = 1.0
    
    
}

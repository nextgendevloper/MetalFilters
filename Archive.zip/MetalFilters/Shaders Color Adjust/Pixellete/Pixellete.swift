//
//  Pixellete.swift
//  MetalFilters
//
//  Created by HKBeast on 29/03/23.
//

import Foundation

class Pixellete:ColorAdjustProtocol{
    var kernalName: String = "pixellete"
    
    var value: Float = 0.01
    
    var min: CGFloat = 0.01
    
    var max: CGFloat = 0.5
    
    
}
